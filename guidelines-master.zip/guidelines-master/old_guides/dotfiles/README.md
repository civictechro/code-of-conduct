Un buchet de fișiere de configurare care se mulează pe guideline-urile noastre.
